#ifndef ESTRUTURAS_H
#define ESTRUTURAS_H

#include <unistd.h>

typedef struct Jogador_Info {
    int id;
    char nome[100];
    char jogo[50];
    int pontuacao;
} Jogador;

// struct estruturas {
//     /* data */
// };

#endif // ESTRUTURAS_H