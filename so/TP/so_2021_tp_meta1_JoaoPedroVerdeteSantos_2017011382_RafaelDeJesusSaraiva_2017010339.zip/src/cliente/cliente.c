#include <stdio.h>
#include <stdlib.h>
#include "constantes.h"
#include "../estruturas.h"

int main() {

    printf("Hello Cliente: %s\n", NONAME);

    return 0;
}