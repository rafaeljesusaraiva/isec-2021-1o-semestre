#ifndef CONSTANTES_H
#define CONSTANTES_H

// VARIÁVEIS CONSTANTES PARA O CLIENTE
#define NONAME "ITS_ME_MARIO"   // Caso o jogador não insira nome

#endif // CONSTANTES_H